BAZAR MANODEVA — proyecto Android inicial

Qué incluye:
- App Android nativa básica, funciona sin conexión.
- Datos guardados localmente en SQLite en el teléfono.
- Inventario, registro de ventas, gastos, personal, asistencia y pagos.
- Moneda euro (€).
- Campo IGIC configurable por producto (valor inicial 7%; confirmar tipo aplicable a cada artículo).

IMPORTANTE:
Este ZIP contiene el CÓDIGO FUENTE de Android, no un APK ya compilado.
No se ha compilado ni firmado un APK en este entorno. No instales archivos de fuentes como si fueran APK.

Cómo generar el APK:
1. En un ordenador, instala Android Studio.
2. Descomprime este ZIP.
3. Android Studio > Open > selecciona la carpeta BazarManodevaAndroid.
4. Espera a que Gradle termine la sincronización.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio mostrará la ubicación del APK. Normalmente:
   app/build/outputs/apk/debug/app-debug.apk
7. Copia ese APK al móvil Android y ábrelo para instalarlo. Puede que Android solicite permitir instalación desde esa fuente.

Notas:
- Esta es una primera versión funcional de base, no un sistema contable certificado.
- El resumen de informes es acumulado, no un cierre mensual fiscal.
- La venta descuenta unidades si el nombre del producto coincide exactamente.
- No incluye todavía escáner de códigos de barras, sincronización entre dispositivos, exportación de facturas ni copias automáticas en la nube.
- Protege el móvil con bloqueo de pantalla y realiza copias de seguridad del dispositivo.
- Revisa con una gestoría los tipos IGIC y requisitos de facturación aplicables en Canarias.

OPCIÓN PARA COMPILAR SIN ORDENADOR (GitHub Actions):
El proyecto incluye .github/workflows/build-apk.yml para intentar compilar el APK en GitHub.
1. Crea una cuenta gratuita en GitHub desde el navegador del móvil.
2. Crea un repositorio nuevo y sube el contenido descomprimido de esta carpeta (incluida la carpeta oculta .github).
3. En el repositorio, abre Actions y selecciona "Build Bazar Manodeva APK".
4. Pulsa "Run workflow" y espera a que termine.
5. Abre la ejecución completada, baja el artefacto "BazarManodeva-debug-apk" y extrae el APK.
6. Abre el APK en el móvil para instalarlo.
La compilación remota depende de GitHub y puede requerir permisos/ajustes del repositorio.
