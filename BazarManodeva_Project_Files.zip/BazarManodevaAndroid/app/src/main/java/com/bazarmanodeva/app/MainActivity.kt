package com.bazarmanodeva.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.NumberFormat
import java.util.Locale

class StoreDb(ctx: Activity) : SQLiteOpenHelper(ctx, "bazar_manodeva.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, sku TEXT, qty INTEGER, cost REAL, price REAL, igic REAL)")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, product TEXT, qty INTEGER, total REAL, payment TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT, note TEXT, amount REAL, payment TEXT, created TEXT DEFAULT CURRENT_TIMESTAMP)")
        db.execSQL("CREATE TABLE staff(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, wage REAL, wage_type TEXT)")
        db.execSQL("CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, staff TEXT, hours REAL, day TEXT DEFAULT CURRENT_DATE)")
        db.execSQL("CREATE TABLE staff_payments(id INTEGER PRIMARY KEY AUTOINCREMENT, staff TEXT, amount REAL, kind TEXT, day TEXT DEFAULT CURRENT_DATE)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun count(table: String): Int {
        val c = readableDatabase.rawQuery("SELECT COUNT(*) FROM $table", null)
        c.moveToFirst(); val n = c.getInt(0); c.close(); return n
    }
    fun sum(table: String, col: String): Double {
        val c = readableDatabase.rawQuery("SELECT COALESCE(SUM($col),0) FROM $table", null)
        c.moveToFirst(); val n = c.getDouble(0); c.close(); return n
    }
    fun rows(sql: String): List<String> {
        val out = mutableListOf<String>()
        val c = readableDatabase.rawQuery(sql, null)
        while (c.moveToNext()) out.add((0 until c.columnCount).joinToString(" • ") { c.getString(it) ?: "" })
        c.close(); return out
    }
}

class MainActivity : Activity() {
    private lateinit var db: StoreDb
    private lateinit var root: LinearLayout
    private val euro = NumberFormat.getCurrencyInstance(Locale("es", "ES"))
    private var page = "Inicio"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = StoreDb(this)
        showPage("Inicio")
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(0xFF202124.toInt())
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }
    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text; setOnClickListener { action() }
    }
    private fun field(hint: String): EditText = EditText(this).apply {
        this.hint = hint; setSingleLine(true)
    }
    private fun money(v: Double) = euro.format(v)

    private fun showPage(name: String) {
        page = name
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(0xFFF6F4EF.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("Inicio", "Ventas", "Stock", "Gastos", "Personal", "Informes").forEach {
            nav.addView(Button(this).apply {
                text = it
                textSize = 10f
                setPadding(dp(2), 0, dp(2), 0)
                setOnClickListener { showPage(it) }
            }, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        root.addView(nav)
        setContentView(root)

        content.addView(label("BAZAR MANODEVA", 25f))
        content.addView(label("Gestión de tienda • Tenerife • €", 13f))
        content.addView(label(name.uppercase(), 18f))
        when (name) {
            "Inicio" -> {
                val sales = db.sum("sales", "total")
                val expenses = db.sum("expenses", "amount")
                content.addView(label("Ventas registradas: ${money(sales)}"))
                content.addView(label("Gastos registrados: ${money(expenses)}"))
                content.addView(label("Productos: ${db.count("products")}"))
                content.addView(label("Personal: ${db.count("staff")}"))
                content.addView(label("Resultado simple: ${money(sales - expenses)}"))
                content.addView(label("Nota: el resultado no descuenta todavía el coste de mercancía ni nóminas si no se registran como gastos."))
            }
            "Ventas" -> {
                content.addView(button("Registrar venta") { addSale() })
                content.addView(label("Historial"))
                db.rows("SELECT product, qty, total, payment, created FROM sales ORDER BY id DESC LIMIT 50").forEach { content.addView(label(it, 13f)) }
            }
            "Stock" -> {
                content.addView(button("Añadir producto") { addProduct() })
                content.addView(label("Inventario"))
                db.rows("SELECT name, sku, qty, cost, price, igic FROM products ORDER BY name").forEach { content.addView(label(it, 13f)) }
            }
            "Gastos" -> {
                content.addView(button("Añadir gasto") { addExpense() })
                db.rows("SELECT category, note, amount, payment, created FROM expenses ORDER BY id DESC LIMIT 50").forEach { content.addView(label(it, 13f)) }
            }
            "Personal" -> {
                content.addView(button("Añadir empleado") { addStaff() })
                content.addView(button("Registrar asistencia") { addAttendance() })
                content.addView(button("Registrar pago / anticipo") { addStaffPayment() })
                content.addView(label("Empleados"))
                db.rows("SELECT name, wage, wage_type FROM staff ORDER BY name").forEach { content.addView(label(it, 13f)) }
                content.addView(label("Asistencia reciente"))
                db.rows("SELECT staff, hours, day FROM attendance ORDER BY id DESC LIMIT 20").forEach { content.addView(label(it, 13f)) }
                content.addView(label("Pagos recientes"))
                db.rows("SELECT staff, amount, kind, day FROM staff_payments ORDER BY id DESC LIMIT 20").forEach { content.addView(label(it, 13f)) }
            }
            "Informes" -> {
                content.addView(label("Resumen acumulado"))
                content.addView(label("Ventas: ${money(db.sum("sales", "total"))}"))
                content.addView(label("Gastos: ${money(db.sum("expenses", "amount"))}"))
                content.addView(label("Pagos al personal: ${money(db.sum("staff_payments", "amount"))}"))
                content.addView(label("Unidades vendidas: ${db.sum("sales", "qty").toInt()}"))
                content.addView(label("IGIC: se guarda por producto como porcentaje configurable. Revisa el tipo aplicable a cada artículo."))
            }
        }
    }

    private fun prompt(title: String, fields: List<Pair<String, EditText>>, save: (List<String>) -> Unit) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fields.forEach { (hint, edit) -> edit.hint = hint; box.addView(edit) }
        AlertDialog.Builder(this).setTitle(title).setView(box)
            .setPositiveButton("Guardar") { _, _ -> save(fields.map { it.second.text.toString().trim() }) }
            .setNegativeButton("Cancelar", null).show()
    }
    private fun addProduct() {
        val f = listOf("Nombre", "SKU / código", "Cantidad", "Coste (€)", "Precio venta (€)", "IGIC (%)").map { it to field(it) }
        prompt("Nuevo producto", f) { v ->
            if (v[0].isNotBlank()) {
                db.writableDatabase.execSQL("INSERT INTO products(name,sku,qty,cost,price,igic) VALUES(?,?,?,?,?,?)",
                    arrayOf(v[0], v[1], v[2].toIntOrNull() ?: 0, v[3].toDoubleOrNull() ?: 0.0, v[4].toDoubleOrNull() ?: 0.0, v[5].toDoubleOrNull() ?: 7.0))
                showPage("Stock")
            }
        }
    }
    private fun addSale() {
        val f = listOf("Producto (nombre exacto)", "Cantidad", "Total cobrado (€)", "Método: Efectivo / Tarjeta").map { it to field(it) }
        prompt("Nueva venta", f) { v ->
            val q = v[1].toIntOrNull() ?: 1
            if (v[0].isNotBlank()) {
                db.writableDatabase.execSQL("INSERT INTO sales(product,qty,total,payment) VALUES(?,?,?,?)",
                    arrayOf(v[0], q, v[2].toDoubleOrNull() ?: 0.0, v[3]))
                db.writableDatabase.execSQL("UPDATE products SET qty=MAX(0,qty-?) WHERE name=?", arrayOf(q, v[0]))
                showPage("Ventas")
            }
        }
    }
    private fun addExpense() {
        val f = listOf("Categoría", "Descripción", "Importe (€)", "Método de pago").map { it to field(it) }
        prompt("Nuevo gasto", f) { v ->
            if (v[0].isNotBlank()) {
                db.writableDatabase.execSQL("INSERT INTO expenses(category,note,amount,payment) VALUES(?,?,?,?)",
                    arrayOf(v[0], v[1], v[2].toDoubleOrNull() ?: 0.0, v[3]))
                showPage("Gastos")
            }
        }
    }
    private fun addStaff() {
        val f = listOf("Nombre empleado", "Salario / tarifa (€)", "Tipo: Mensual u Hora").map { it to field(it) }
        prompt("Nuevo empleado", f) { v ->
            if (v[0].isNotBlank()) {
                db.writableDatabase.execSQL("INSERT INTO staff(name,wage,wage_type) VALUES(?,?,?)",
                    arrayOf(v[0], v[1].toDoubleOrNull() ?: 0.0, v[2]))
                showPage("Personal")
            }
        }
    }
    private fun addAttendance() {
        val f = listOf("Nombre empleado", "Horas trabajadas").map { it to field(it) }
        prompt("Registrar asistencia", f) { v ->
            if (v[0].isNotBlank()) {
                db.writableDatabase.execSQL("INSERT INTO attendance(staff,hours) VALUES(?,?)",
                    arrayOf(v[0], v[1].toDoubleOrNull() ?: 0.0))
                showPage("Personal")
            }
        }
    }
    private fun addStaffPayment() {
        val f = listOf("Nombre empleado", "Importe (€)", "Tipo: Salario / Anticipo / Bonus").map { it to field(it) }
        prompt("Pago al personal", f) { v ->
            if (v[0].isNotBlank()) {
                db.writableDatabase.execSQL("INSERT INTO staff_payments(staff,amount,kind) VALUES(?,?,?)",
                    arrayOf(v[0], v[1].toDoubleOrNull() ?: 0.0, v[2]))
                showPage("Personal")
            }
        }
    }
}
